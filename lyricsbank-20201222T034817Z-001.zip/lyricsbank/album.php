﻿
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Lyricsbank | album</title>
<meta charset="UTF-8">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/cufon-yui.js" type="text/javascript"></script>
<script src="js/cufon-replace.js" type="text/javascript"></script>
<script type="text/javascript" src="js/Josefin_Sans_600.font.js"></script>
<script type="text/javascript" src="js/Lobster_400.font.js"></script>
<script type="text/javascript" src="js/sprites.js"></script>
<script type="text/javascript" src="js/jquery.jplayer.min.js"></script>
<script type="text/javascript" src="js/jquery.jplayer.settings.js"></script>
<script type="text/javascript" src="js/gSlider.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
</head>
<body id="page3">
<!-- START PAGE SOURCE -->
<div id="main">
  <header>
    <nav>
      <ul>

        <li><a href="login.php">Home</a></li>
    <li><a href="album.php">Album</a></li>
        <li><a href="video.php">Video</a></li>
        <li><a href="about.php">About </a></li>
            <li><a href="register.php">Register</a></li>
                <li><a href="contact.php">Contact </a></li>



      </ul>
    </nav>
    <h1><a href="index.html">Lyricsbank</a></h1>
    <div class="header-slider">
      <ul>
        <li>Lyricsbank is a huge collection of song lyrics, album information and featured video clips from endless number of artists — collaboratively assembled by contributing editors.</li>
        <li>This website has several pages: Home, Album, Video, About, Register, Contact (note that contact us form – doesn’t work).</li>
        <li>edited our lyrics and artists database . Lyrics can be written using song videos and even translated to many common and not so common languages.</li>
      </ul>
    </div>
    <a href="#" class="hs-prev"><img src="images/prev.png" alt=""></a> <a href="#" class="hs-next"><img src="images/next.png" alt=""></a> <a href="#" class="header-more">Read More</a> </header>
  <article id="content">
    <div class="col-1">
      <div class="p2">
        <h2>New Album</h2>
        <img src="images/col-1-img1.png" class="p1" alt=""> <a href="album.php" class="more">Read More</a></div>
      <div class="p2">
        <h2>Latest Photos</h2>
        <a href="gallery.php"><img class="p1" src="images/col1-img2.jpg" alt=""></a>
        <div class="alc"><a href="gallery.php">View Gallery</a></div>
      </div>
    </div>
    <div class="col-2">
        <div class="p0">
      <h2>Video</h2>
      <?php
       include('config.php');

      $sql = "SELECT * FROM `album-lists`";
      $result=mysqli_query($conn,$sql);
      if($result==false){
        echo "error while executing mysql: " .mysqli_error($conn);
      }
      ?>
      <table border=2>
      <form>
      <tr >
      <td width="50" ><b>ID       </b></td>
      <td width="50" height="50"><b>Artist        </b></td>
      <td width="50" height="50"><b>Album         </b></td>
      <td width="50" height="50"><b>Songs         </b></td>

      </tr>

      <?php

      if(mysqli_num_rows($result)>0)
      {
      	while($row=mysqli_fetch_assoc($result))
      	{
          echo"<tr><td>".$row['id']."</td>";
      		echo"<td>".$row['Artist']."</td>";

      		echo"<td>".$row['Album']."</td>";
      		echo"<td>".$row['Songs']."</td>";
      		echo"<td><a href ='insertAlbum.php?j=".$row['id']."'><input class='more' type='button' value='Update'></a></td>";

      	}
      }

      ?>


      <tr>
      <td colspan=4></td>
      <td colspan=2><a href ="insertAlbum.php"><input class="more"  type="button" value="Add "></td></a>
      </tr>
      </form>
      </table>
      </div>

</div>

    <div class="col-3">
      <h2>Latest Tweets</h2>
      <div class="und">
        <p>Now we can get Havana lyric!#Camila Cabello<br>
          <a href="https://www.twitter.com">1 hour ago</a></p>
        <p>This Song is great.Lyric distribution is equal and lyric is incredible.#LOOK<br>
          <a href="https://www.twitter.com">3 hours ago</a></p>
        <p>Shape of you is dope!Music style are attractive and active.#Shape of you<br>
          <a href="https://www.twitter.com">7 hours ago</a></p>
        <p>Great!Great!Fine is Explosion and I is relaxion.#Taeyeon<br>
          <a href="https://www.twitter.com">12 hours ago</a></p>
        <p>Call it what you want Lyric are uploaded in youtube.#Taylor Swift<br>
          <a href="https://www.twitter.com">16 hours ago</a></p>
      </div>
      <h2>Newsletter</h2>
      <form action="#" id="subscribe">
        <fieldset>
          <label>
            <input type="text">
          </label>
          <input type="submit" value="">
        </fieldset>
      </form>
      <h2>Find Me</h2>
      <ul class="soc-ico">
        <li><a href="https://www.facebook.com"><img src="images/facebook.png" alt=""></a></li>
        <li><a href="https://www.twitter.com"><img src="images/twitter.png" alt=""></a></li>
        <li><a href="https://www.myspace.com"><img src="images/myspace.png" alt=""></a></li>
        <li><a href="https://www.linkedin.com"><img src="images/linkedin.png" alt=""></a></li>
      </ul>
    </div>
  </article>
  <div class="af clear"></div>
</div>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2011 <a href="#">SiteName</a> - All Rights Reserved</p>
    <p class="rf">Design by <a href="http://www.templatemonster.com/">TemplateMonster</a></p>
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">Cufon.now()
$(function () {
    $('nav,.more,.header-more').sprites()
    $('.header-slider').gSlider({
        prevBu: '.hs-prev',
        nextBu: '.hs-next'
    })
})
</script>
<!-- END PAGE SOURCE -->
</body>
</html>
