<?php
include('config.php');
$id=$_GET['j'];
$sql= "DELETE FROM `lyric_lists` WHERE `lyric_lists`.`id` = $id";
$result=mysqli_query($conn,$sql);
if($result){
echo "New record is deleted successfully";
header("Location:index.php");
}else
echo "Error:" .$sql."<br>".mysqli_error($conn);


?>
