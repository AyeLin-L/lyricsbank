<?php
include('config.php');
session_start();
$table_name = "admin";
$backup_file = "J:/songdb.sql";
$sql = "SELECT * INTO OUTFILE '$backup_file' FROM $table_name";

$retval = mysqli_query( $conn, $sql);
if(! $retval ) {
die('Could not take data backup: ' . mysqli_error($conn));
}

echo "Backedup data successfully\n";

?>
