<?php
include('config.php');
session_start();
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
$myusername=mysqli_real_escape_string($conn,$_POST['name']);
$mypassword=mysqli_real_escape_string($conn,$_POST['pass']);

$sql="SELECT id FROM admin WHERE username='$myusername' and password='$mypassword'";
$result=mysqli_query($conn,$sql);

    $_SESSION['login_user']=$myusername;
  header("LOCATION:welcome.php");


  $error="Your login Name or Password is invalid";
  echo"$error";

}
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Lyricsbank | Home</title>
<meta charset="UTF-8">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css">
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/cufon-yui.js" type="text/javascript"></script>
<script src="js/cufon-replace.js" type="text/javascript"></script>
<script type="text/javascript" src="js/Josefin_Sans_600.font.js"></script>
<script type="text/javascript" src="js/Lobster_400.font.js"></script>
<script type="text/javascript" src="js/sprites.js"></script>
<script type="text/javascript" src="js/gSlider.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>

</head>
<body id="page5">
<!-- START PAGE SOURCE -->
<div id="main">
  <header>
    <nav>
      <ul>

        <li><a href="login.php">Home</a></li>
    <li><a href="album.php">Album</a></li>
        <li><a href="video.php">Video</a></li>
        <li><a href="about.php">About </a></li>
            <li><a href="register.php">Register</a></li>
                <li><a href="contact.php">Contact </a></li>


      </ul>
    </nav>
    <h1><a href="index.html">Lyricsbank</a></h1>
    <div class="header-slider">
      <ul>
        <li>Lyricsbank is a huge collection of song lyrics, album information and featured video clips from endless number of artists — collaboratively assembled by contributing editors.</li>
        <li>This website has several pages: Home, Album, Video, About, Register, Contact (note that contact us form – doesn’t work).</li>
        <li>edited our lyrics and artists database . Lyrics can be written using song videos and even translated to many common and not so common languages.</li>
      </ul>
    </div>
    <a href="#" class="hs-prev"><img src="images/prev.png" alt=""></a> <a href="#" class="hs-next"><img src="images/next.png" alt=""></a> <a href="#" class="header-more">Read More</a> </header>
  <article id="content">
    <div class="col-1">
      <div class="p2">
        <h2>New Album</h2>
        <img src="images/col-1-img1.png" class="p1" alt=""> <a href="album.php" class="more">Read More</a></div>
      <div class="p2">
        <h2>New Video</h2>
        <a href="#"><img class="p1" src="images/col1-video-thumb1.jpg" alt=""></a>
        <div class="alc"><a href="video.php">More Videos</a></div>
      </div>
      <div class="p2">
        <h2>Latest Photos</h2>
        <a href="gallery.php"><img class="p1" src="images/col1-img2.jpg" alt=""></a>
        <div class="alc"><a href="gallery.php">View Gallery</a></div>
      </div>
    </div>



      <div class="col-2">
        <h2>Login</h2>
        <form method="post" id="form1">
          <fieldset>
            <label> Name:
              <input type="text" name="name">
            </label>
            <label> Password:
              <input type="password" name="pass">
            </label>

  <input type="submit" class="more" value="Send" name="log" ></div>
          </fieldset>
        </form>


<div class="col-3">
  <h2>Latest Tweets</h2>
  <div class="und">
    <p>Now we can get Havana lyric!#Camila Cabello<br>
      <a href="https://www.twitter.com">1 hour ago</a></p>
    <p>This Song is great.Lyric distribution is equal and lyric is incredible.#LOOK<br>
      <a href="https://www.twitter.com">3 hours ago</a></p>
    <p>Shape of you is dope!Music style are attractive and active.#Shape of you<br>
      <a href="https://www.twitter.com">7 hours ago</a></p>
    <p>Great!Great!Fine is Explosion and I is relaxion.#Taeyeon<br>
      <a href="https://www.twitter.com">12 hours ago</a></p>
    <p>Call it what you want Lyric are uploaded in youtube.#Taylor Swift<br>
      <a href="https://www.twitter.com">16 hours ago</a></p>
  </div>
  <h2>Newsletter</h2>
  <form action="#" id="subscribe">
    <fieldset>
      <label>
        <input type="text">
      </label>
      <input type="submit" value="">
    </fieldset>
  </form>
  <h2>Find Me</h2>
  <ul class="soc-ico">
    <li><a href="https://www.facebook.com"><img src="images/facebook.png" alt=""></a></li>
    <li><a href="https://www.twitter.com"><img src="images/twitter.png" alt=""></a></li>
    <li><a href="https://www.myspace.com"><img src="images/myspace.png" alt=""></a></li>
    <li><a href="https://www.linkedin.com"><img src="images/linkedin.png" alt=""></a></li>
  </ul>
</div>
</article>
<div class="af clear"></div>
</div>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2011 <a href="#">SiteName</a> - All Rights Reserved</p>
    <p class="rf">Design by <a href="http://www.templatemonster.com/">TemplateMonster</a></p>
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">Cufon.now()
$(function () {
    $('nav,.more,.header-more').sprites()
    $('.header-slider').gSlider({
        prevBu: '.hs-prev',
        nextBu: '.hs-next'
    })
    $('a[rel=prettyPhoto]').each(function () {
        var th = $(this),
            pb
            th.append(pb = $('<span class="playbutt"></span>').css({
                opacity: .7
            }))
            pb.bind('mouseenter', function () {
                $(this).stop().animate({
                    opacity: .9
                })
            }).bind('mouseleave', function () {
                $(this).stop().animate({
                    opacity: .7
                })
            })
    }).prettyPhoto({
        theme: 'dark_square'
    })
})
</script>
<!-- END PAGE SOURCE -->
</body>
</html>
