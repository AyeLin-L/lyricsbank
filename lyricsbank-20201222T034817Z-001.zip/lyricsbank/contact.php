<?php
include("config.php");
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$name=$_POST['name'];
$email=$_POST['email'];

$city=$_POST['city'];
$message=$_POST['msg'];
if($name!=null && $email!=null&&$city!=null&&$message!=null){
$sql = "INSERT INTO `contact-lists` ( `Name`,`Email`, `City`,`Message`) VALUES ( '$name','$email' ,'$city','$message')";
$result=mysqli_query($conn,$sql);
if($result){
echo "New record is created successfully";
header("Location:index.php");
}else
echo "Error:" .$sql."<br>".mysqli_error($conn);
}
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Lyricsbank | Contacts</title>
<meta charset="UTF-8">
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css">
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/cufon-yui.js" type="text/javascript"></script>
<script src="js/cufon-replace.js" type="text/javascript"></script>
<script type="text/javascript" src="js/Josefin_Sans_600.font.js"></script>
<script type="text/javascript" src="js/Lobster_400.font.js"></script>
<script type="text/javascript" src="js/sprites.js"></script>
<script type="text/javascript" src="js/gSlider.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
<!--[if lt IE 7]> <div style=' clear: both; height: 59px; padding:0 0 0 15px; position: relative;'> <a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." /></a></div> <![endif]-->
<!--[if lt IE 9]><script src="js/html5.js" type="text/javascript"></script><![endif]-->
<!--[if IE]><link href="css/ie_style.css" rel="stylesheet" type="text/css" /><![endif]-->
</head>
<body id="page6">
<!-- START PAGE SOURCE -->
<div id="main">
  <header>
    <nav>
      <ul>

                <li><a href="login.php">Home</a></li>
            <li><a href="album.php">Album</a></li>
                <li><a href="video.php">Video</a></li>
                <li><a href="about.php">About </a></li>
                    <li><a href="register.php">Register</a></li>
        <li class="active"><a href="contact.php">Contact</a></li>
      </ul>
    </nav>
    <h1><a href="index.html">Lyricsbank</a></h1>
    <div class="header-slider">
      <ul>
        <li>Lyricsbank is a huge collection of song lyrics, album information and featured video clips from endless number of artists — collaboratively assembled by contributing editors.</li>
        <li>This website has several pages: Home, Album, Video, About, Register, Contact (note that contact us form – doesn’t work).</li>
        <li>edited our lyrics and artists database . Lyrics can be written using song videos and even translated to many common and not so common languages.</li>
      </ul>
    </div>
    <a href="#" class="hs-prev"><img src="images/prev.png" alt=""></a> <a href="#" class="hs-next"><img src="images/next.png" alt=""></a> <a href="#" class="header-more">Read More</a> </header>
  <article id="content">
    <div class="col-1">
      <div class="p2">
        <h2>New Album</h2>
        <img src="images/col-1-img1.png" class="p1" alt=""> <a href="#" class="more">Read More</a></div>
      <div class="p2">
        <h2>New Video</h2>
        <a href="#"><img class="p1" src="images/col1-video-thumb1.jpg" alt=""></a>
        <div class="alc"><a href="video.php">More Videos</a></div>
      </div>
      <div class="p2">
        <h2>Latest Photos</h2>
        <a href="gallery.php"><img class="p1" src="images/col1-img2.jpg" alt=""></a>
        <div class="alc"><a href="gallery.php">View Gallery</a></div>
      </div>
    </div>
    <div class="col-2">
      <h2>Contact Form</h2>
      <form action="#" id="form1" method="post">
        <fieldset>
          <label>Your Name:
            <input type="text" name="name">
          </label>
          <label>Your E-mail:
            <input type="email" name="email">
          </label>
          <label>Your City:
            <input type="text" name="city">
          </label>
          <label class="msg">Your Message:
            <textarea name="msg"></textarea>
          </label>
          <div class="btns"> <input type="submit" class="more" value="Send" name="log" ></div>
        </fieldset>
      </form>
    </div>
    <div class="col-3">
      <h2>Our Contacts</h2>
      <ul class="contacts blo">
        <li><span>Country:</span>Myanmar</li>
        <li><span>State:</span>Yangon</li>
        <li><span>City:</span>Yangon</li>
        <li><span>Telephone:</span>+95963856319</li>
        <li><span>Email:</span><a href="#">ayelinphyu2017@mail.com</a></li>
      </ul>
      <h2>Miscellaneous</h2>
      <p>Thank you for contacting us.We can give best response as much as we can from your contact.</p>
      <h2>Newsletter</h2>
      <form action="#" id="subscribe">
        <fieldset>
          <label>
            <input type="text">
          </label>
          <input type="submit" value="">
        </fieldset>
      </form>
      <h2>Find Me</h2>
      <ul class="soc-ico">
        <li><a href="https://www.facebook.com"><img src="images/facebook.png" alt=""></a></li>
        <li><a href="https://www.twitter.com"><img src="images/twitter.png" alt=""></a></li>
        <li><a href="https://www.myspace.com"><img src="images/myspace.png" alt=""></a></li>
        <li><a href="https://www.linkedin.com"><img src="images/linkedin.png" alt=""></a></li>
      </ul>
    </div>
  </article>
  <div class="af clear"></div>
</div>
<footer>
  <div class="footerlink">
    <p class="lf">Copyright &copy; 2011 <a href="#">SiteName</a> - All Rights Reserved</p>
    <p class="rf">Design by <a href="http://www.templatemonster.com/">TemplateMonster</a></p>
    <div style="clear:both;"></div>
  </div>
</footer>
<script type="text/javascript">Cufon.now()
$(function () {
    $('nav,.more,.header-more').sprites()
    $('.header-slider').gSlider({
        prevBu: '.hs-prev',
        nextBu: '.hs-next'
    })
    $('a[rel=prettyPhoto]').each(function () {
        var th = $(this),
            pb
            th.append(pb = $('<span class="playbutt"></span>').css({
                opacity: .7
            }))
            pb.bind('mouseenter', function () {
                $(this).stop().animate({
                    opacity: .9
                })
            }).bind('mouseleave', function () {
                $(this).stop().animate({
                    opacity: .7
                })
            })
    }).prettyPhoto({
        theme: 'dark_square'
    })
})
</script>
<!-- END PAGE SOURCE -->
</body>
</html>
