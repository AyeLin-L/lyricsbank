<?php
include('config.php');
$table_name = "admin";
$backup_file = "J:/admin.sql";
$sql = "LOAD DATA INFILE '$backup_file' INTO TABLE $table_name";

$retval = mysqli_query($conn, $sql );
if(! $retval ) {
die('Could not load data : ' . mysqli_error($conn));
}
echo "Loaded data successfully\n";

?>
