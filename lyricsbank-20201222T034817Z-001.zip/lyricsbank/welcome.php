<?php
include("lock.php");
header("LOCATION:login.php");
?>
