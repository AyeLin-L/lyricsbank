Cufon.replace('nav a', { fontFamily: 'Josefin Sans' ,textShadow:'1px 1px #fff', hover:{}});
Cufon.replace('h1 a', { fontFamily: 'Lobster' , color:'-linear-gradient(#414141,#2d2d2d)',textShadow:'-1px -1px #000'});
Cufon.replace('h2', { fontFamily: 'Lobster' });

Cufon.replace('.header-more', { fontFamily: 'Lobster',textShadow:'1px 1px #000' ,hover:{color:'#74be00'} });
Cufon.replace('.jp-audio .jp-title', { fontFamily: 'Josefin Sans' });
Cufon.replace('.jp-audio h2', { fontFamily: 'Lobster', textShadow:'2px 2px rgba(0,0,0,.1)' });
